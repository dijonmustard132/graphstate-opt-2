**Table 1. Test split (budget 10,000 work units; planted 300,000; 10 seeds)**

| Method | ER random | Bounded degree | Resource states | Trees | GHZ-type | Repeater-like | Planted n=30 | All (excl. planted) |
|---|---|---|---|---|---|---|---|---|
| SA (LC) | 1.019 (79%) | 1.001 (99%) | 1.002 (97%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.004 (95%) |
| SA (LC+pivot) | 1.003 (94%) | 1.001 (99%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.001 (99%) |
| ILS (LC) | 1.003 (95%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (99%) |
| ILS (LC+pivot) | 1.003 (95%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.001 (99%) |
| Tabu (LC) | 1.029 (67%) | 1.000 (100%) | 1.013 (85%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.121 (50%) | 1.008 (91%) |
| Tabu commit (LC) | 1.002 (96%) | 1.000 (100%) | 1.002 (97%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.001 (99%) |
| Tabu (LC+pivot) | 1.001 (99%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) |
| Tabu (pivot only) | 1.438 (7%) | 1.134 (0%) | 1.302 (6%) | 1.356 (10%) | 1.305 (50%) | 1.184 (27%) | 1.216 (0%) | 1.296 (18%) |

Instances per class: ER random 14, Bounded degree 10, Resource states 18, Trees 10, GHZ-type 16, Repeater-like 11, Planted n=30 4. Cells: mean found/MER (share of runs reaching the exact minimum).

**Table 2. Effect of adding pivot moves, test split**

| Comparison (first minus second) | ER random | Bounded degree | Resource states | Trees | GHZ-type | Repeater-like | All (orbits) | 95% CI (all) |
|---|---|---|---|---|---|---|---|---|
| SA: SA (LC+pivot) - SA (LC) | -0.016 | -0.000 | -0.002 | +0.000 | +0.000 | +0.000 | -0.0054 (exact-hit +5.5 pts, 44 orbits) | [-0.0097, -0.0020] |
| ILS: ILS (LC+pivot) - ILS (LC) | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 | +0.0000 (exact-hit -0.0 pts, 44 orbits) | [-0.0007, +0.0009] |
| Tabu: Tabu (LC+pivot) - Tabu (LC) | -0.028 | +0.000 | -0.013 | +0.000 | +0.000 | +0.000 | -0.0107 (exact-hit +12.0 pts, 44 orbits) | [-0.0200, -0.0038] |
| Tabu vs commit: Tabu (LC+pivot) - Tabu commit (LC) | -0.001 | +0.000 | -0.002 | +0.000 | +0.000 | +0.000 | -0.0007 (exact-hit +1.3 pts, 44 orbits) | [-0.0019, +0.0000] |

Negative = the pivot variant found smaller graphs. Unit of analysis = orbit (seeds and starts averaged within an orbit).

**Table 3. Same comparison pooled over all splits (more orbits; robustness check)**

| Comparison (first minus second) | ER random | Bounded degree | Resource states | Trees | GHZ-type | Repeater-like | All (orbits) | 95% CI (all) |
|---|---|---|---|---|---|---|---|---|
| SA: SA (LC+pivot) - SA (LC) | -0.010 | -0.000 | -0.001 | +0.000 | +0.000 | +0.000 | -0.0034 (exact-hit +3.4 pts, 111 orbits) | [-0.0055, -0.0015] |
| ILS: ILS (LC+pivot) - ILS (LC) | +0.001 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 | +0.0003 (exact-hit -0.5 pts, 111 orbits) | [-0.0002, +0.0009] |
| Tabu: Tabu (LC+pivot) - Tabu (LC) | -0.019 | -0.000 | -0.014 | +0.000 | -0.000 | +0.000 | -0.0083 (exact-hit +9.8 pts, 111 orbits) | [-0.0126, -0.0047] |
| Tabu vs commit: Tabu (LC+pivot) - Tabu commit (LC) | -0.001 | +0.000 | -0.001 | +0.000 | +0.000 | +0.000 | -0.0006 (exact-hit +1.1 pts, 111 orbits) | [-0.0012, -0.0001] |

Negative = the pivot variant found smaller graphs. Unit of analysis = orbit (seeds and starts averaged within an orbit).

**Table 4. All splits pooled**

| Method | ER random | Bounded degree | Resource states | Trees | GHZ-type | Repeater-like | Planted n=30 | All (excl. planted) |
|---|---|---|---|---|---|---|---|---|
| SA (LC) | 1.013 (85%) | 1.000 (100%) | 1.001 (99%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.003 (97%) |
| SA (LC+pivot) | 1.003 (95%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.001 (99%) |
| ILS (LC) | 1.002 (97%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (99%) |
| ILS (LC+pivot) | 1.003 (95%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (99%) |
| Tabu (LC) | 1.020 (76%) | 1.000 (100%) | 1.014 (86%) | 1.000 (100%) | 1.000 (99%) | 1.000 (100%) | 1.117 (40%) | 1.007 (92%) |
| Tabu commit (LC) | 1.002 (96%) | 1.000 (100%) | 1.001 (99%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (99%) |
| Tabu (LC+pivot) | 1.000 (99%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) | 1.000 (100%) |
| Tabu (pivot only) | 1.305 (11%) | 1.166 (4%) | 1.286 (2%) | 1.342 (8%) | 1.301 (55%) | 1.139 (36%) | 1.190 (0%) | 1.265 (21%) |

Instances per class: ER random 36, Bounded degree 24, Resource states 45, Trees 24, GHZ-type 44, Repeater-like 28, Planted n=30 10. Cells: mean found/MER (share of runs reaching the exact minimum).
