import csv, statistics as st, collections
METH = ["SA (LC)", "SA (LC+pivot)", "ILS (LC)", "ILS (LC+pivot)", "Tabu (LC)", "Tabu commit (LC)", "Tabu (LC+pivot)", "Tabu (pivot only)"]
SMALL = [500, 1000, 2000, 4000, 10000]; PL = [20000, 50000, 100000, 300000]
def load(splits):
    d = collections.defaultdict(list)       # (method, budget, class, instance) -> [(ratio, exact)]
    for sp in splits:
        for r in csv.DictReader(open(f"../results/sweep_{sp}.csv")):
            f, m = int(r['found']), int(r['mer'])
            d[(r['method'], int(r['budget']), r['class'], r['id'])].append((f / m, f == m))
    return {k: (st.mean(x[0] for x in v), st.mean(x[1] for x in v)) for k, v in d.items()}
def cell(inst, m, b, classes):
    v = [x for k, x in inst.items() if k[0] == m and k[1] == b and k[2] in classes]
    return f"{st.mean(x[0] for x in v):.3f} ({100*st.mean(x[1] for x in v):.0f}%)", len(v)
def tab(inst, title, classes, budgets):
    n = cell(inst, METH[0], budgets[0], classes)[1]
    L = [f"**{title}** ({n} instances)", "", "| Method | " + " | ".join(f"{b:,}" for b in budgets) + " |", "|---|" + "---|" * len(budgets)]
    for m in METH: L.append(f"| {m} | " + " | ".join(cell(inst, m, b, classes)[0] for b in budgets) + " |")
    return "\n".join(L)
SIX = {"ER", "BD", "RES", "TREE", "GHZ", "REP"}
sel = load(["train", "val"]); test = load(["test"])
parts = [tab(sel, "Table A. Budget sweep on train+val (use this to CHOOSE budgets), six classes pooled, n<=12", SIX, SMALL), "",
         tab(sel, "Table B. Same, ER random only (the hardest class)", {"ER"}, SMALL), "",
         tab(sel, "Table C. Same, resource states only", {"RES"}, SMALL), "",
         tab(test, "Table D. Budget sweep on TEST (report this), six classes pooled", SIX, SMALL), "",
         tab(test, "Table E. TEST, ER random only", {"ER"}, SMALL), "",
         tab(load(["train", "val", "test"]), "Table F. Planted n=30 trees (budget in work units), all splits pooled", {"PLANT"}, PL)]
open("../results/budget_sweep.md", "w").write("\n".join(parts) + "\n"); print("\n".join(parts))
